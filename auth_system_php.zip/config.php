<?php
$servername = "localhost";
$username = "s66160041";
$password = "5am54Meh";
$dbname = "eye_tracking";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>